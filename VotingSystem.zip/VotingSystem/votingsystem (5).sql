-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2024 at 07:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `CandidateId` int(10) NOT NULL,
  `CandidateName` varchar(45) NOT NULL,
  `CandidateAge` int(10) NOT NULL,
  `Citizenship` varchar(45) NOT NULL,
  `PoliticalParty` varchar(45) NOT NULL,
  `CandidateAddress` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`CandidateId`, `CandidateName`, `CandidateAge`, `Citizenship`, `PoliticalParty`, `CandidateAddress`) VALUES
(1, 'Pravin Padul', 22, 'Indian', 'Congress Party', 'Jalana'),
(2, 'Mohmmad Shaikh', 23, 'Indian', 'ShivSena', 'Pune'),
(3, 'Shivshankar Gavli', 23, 'Indian', 'BJP', 'Pune');

-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE `election` (
  `electionId` int(10) NOT NULL,
  `electionDate` varchar(45) NOT NULL,
  `startTime` varchar(12) NOT NULL,
  `endTime` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`electionId`, `electionDate`, `startTime`, `endTime`) VALUES
(0, '2024-07-10', '10:30 am', '17:35'),
(1, '2024-07-08', '10:30', '17:30');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `userType` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `userType`) VALUES
('Aditya', 'Aditya123', 'voter'),
('Aditya pawar ', '123456', 'candidates'),
('Avinash', 'Avinash@123', 'voter'),
('Pravin', 'Pravin@143', 'candidate'),
('Shridhar', 'Shridhar@123', 'voter'),
('Vikas', 'Vikas@123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `electionId` int(11) NOT NULL,
  `resultDate` varchar(12) NOT NULL,
  `resultTime` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`electionId`, `resultDate`, `resultTime`) VALUES
(0, '22/07/2024', '12:30');

-- --------------------------------------------------------

--
-- Table structure for table `voter`
--

CREATE TABLE `voter` (
  `VoterId` int(45) NOT NULL,
  `VoterName` varchar(45) NOT NULL,
  `Age` int(5) NOT NULL,
  `Citizenship` varchar(45) NOT NULL,
  `DOB` varchar(45) NOT NULL,
  `Address` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voter`
--

INSERT INTO `voter` (`VoterId`, `VoterName`, `Age`, `Citizenship`, `DOB`, `Address`) VALUES
(1, 'Aditya Pawar', 21, 'Indian', '12/01/2002', 'Satara'),
(2, 'Prasad Kale', 22, 'Indian', '12/10/2001', 'Chhatrapati Sambhajinagar'),
(3, 'Shridhar Patil', 21, 'Indian', '30/06/2000', 'Satara'),
(4, 'Gokul Gunjal', 23, 'Indian', '04/06/2003', 'Sangamner'),
(5, 'Vikas Gupta', 25, 'Indian', '08/05/1999', 'Gorakhpur'),
(6, 'Adesh Narwade', 23, 'Indian', '04/06/2003', 'Jalgaon'),
(7, 'Rushak Pachpande', 24, 'Indian', '30/06/2001', 'Pune'),
(8, 'Avinash Bhalerao', 24, 'Indian', '21/10/2002', 'Parbhani'),
(9, 'Bhushan Dongre', 23, 'Indian', '30/06/2001', 'Sangamner'),
(10, 'Vikas Gawande', 24, 'Indian', '08/05/1999', 'Amravati');

-- --------------------------------------------------------

--
-- Table structure for table `voting`
--

CREATE TABLE `voting` (
  `votingId` int(11) NOT NULL,
  `candidateId` int(45) NOT NULL,
  `voterId` int(45) NOT NULL,
  `vote` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voting`
--

INSERT INTO `voting` (`votingId`, `candidateId`, `voterId`, `vote`) VALUES
(1, 2, 1, NULL),
(2, 2, 8, NULL),
(3, 1, 3, NULL),
(4, 1, 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`CandidateId`);

--
-- Indexes for table `election`
--
ALTER TABLE `election`
  ADD PRIMARY KEY (`electionId`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`electionId`);

--
-- Indexes for table `voter`
--
ALTER TABLE `voter`
  ADD PRIMARY KEY (`VoterId`);

--
-- Indexes for table `voting`
--
ALTER TABLE `voting`
  ADD PRIMARY KEY (`votingId`),
  ADD UNIQUE KEY `candidateId` (`candidateId`,`voterId`),
  ADD UNIQUE KEY `candidateId_2` (`candidateId`,`voterId`),
  ADD KEY `voterId` (`voterId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `voting`
--
ALTER TABLE `voting`
  MODIFY `votingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `Foreign key` FOREIGN KEY (`electionId`) REFERENCES `election` (`electionId`);

--
-- Constraints for table `voting`
--
ALTER TABLE `voting`
  ADD CONSTRAINT `voting_ibfk_2` FOREIGN KEY (`voterId`) REFERENCES `voter` (`VoterId`),
  ADD CONSTRAINT `voting_ibfk_3` FOREIGN KEY (`candidateId`) REFERENCES `candidate` (`CandidateId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
