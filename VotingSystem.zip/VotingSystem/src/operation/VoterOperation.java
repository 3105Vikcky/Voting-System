package operation;

import java.util.Scanner;
import java.util.List;

import dao.VoterDAO;
import model.Voter;

public class VoterOperation 
{
	
	public static void addVoters(Scanner sc)
	{
		System.out.println("Enter Voter Id: ");
		int Voter_id =sc.nextInt();
		
		sc.nextLine();
		
		System.out.println("Enter Voter Name: ");
		String Voter_Name=sc.nextLine();
		
		System.out.println("Enter  Voter Age: ");
		int Voter_Age=sc.nextInt();
		
		sc.nextLine();
		
		System.out.println("Enter Voter Citizenship: ");
		String Voter_Citizenship=sc.nextLine();
		
		System.out.println("Enter Voter DOB [dd/mm/yyyy] : ");
		String Voter_DOB=sc.nextLine();
		
		System.out.println("Enter Voter Address: ");
		String Voter_Address=sc.nextLine();
		
		//Creating Object of Voter Class
		Voter obj= new Voter(Voter_id, Voter_Name, Voter_Age, Voter_Citizenship, Voter_DOB, Voter_Address);
		
		boolean result=VoterDAO.insert(obj);
		
		if(result)
		{
			System.out.println("Voter Added Successfully ");
			System.out.println("To Continue Follow the steps.....");
		}
		else {
			System.out.println("Something went wrong!");
		}
	
	}
	
	// Update Voters
	public static void updateVoter(Scanner sc)
	{
		System.out.println("Enter Id to which update:");
        int VoterId = sc.nextInt();
        
        sc.nextLine();
        
        System.out.println("Enter  Name: ");
		String Voter_Name=sc.nextLine();
		
		System.out.println("Enter   Age: ");
		int Voter_Age=sc.nextInt();
		
		sc.nextLine();
		
		System.out.println("Enter  Citizenship: ");
		String Voter_Citizenship=sc.nextLine();
		
		System.out.println("Enter  DOB [dd/mm/yyyy] : ");
		String Voter_DOB=sc.nextLine();
		
		System.out.println("Enter  Address: ");
		String Voter_Address=sc.nextLine();
		
		//Creating Object of Voter Class
		Voter obj= new Voter(VoterId, Voter_Name, Voter_Age, Voter_Citizenship, Voter_DOB, Voter_Address);
		
		boolean result=VoterDAO.update(obj,VoterId);
		
		if(result)
		{
			System.out.println("Voter Updated Successfully ");
		}
		else {
			System.out.println("Something went wrong!");
		}

	}
	
	//delete VoterByID
	public static void deleteVoterByID(Scanner sc)
	{
		System.out.println("Enter Voter ID which you want to delete: ");
		int VoterID=sc.nextInt();
		
		boolean result=VoterDAO.delete(VoterID);
		
		if(result)
		{
			System.out.println("Voter Delete Successfully ");
		}
		else {
			System.out.println("Something went wrong!");
		}
		
	}
	
	//show voter by id
	public static void showVoterByID(Scanner sc)
	{
		System.out.println("Enter Voter ID Which you want to show: ");
		int VoterID=sc.nextInt();
		
		Voter voter=VoterDAO.getVoterId(VoterID);
		
		if (voter != null) 
		{
            System.out.println(voter);
        } else 
        {
            System.out.println("Voter with ID " + VoterID + " not found.");
        }
	}
	
	// Show All Voters
	public static void ShowAllVoters()
	{
		List<Voter> Voters = VoterDAO.getAllVoters();
        for (Voter voter : Voters) 
        {
        	System.out.println(voter);
        }
	}
	
	
}
