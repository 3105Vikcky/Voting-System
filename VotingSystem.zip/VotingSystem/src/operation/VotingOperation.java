package operation;

import java.util.Scanner;

import dao.VotingDAO;
import model.VotingProcess;

public class VotingOperation 
{
	public static void castVote()
	{
		try {
		Scanner sc=new Scanner(System.in);
		System.out.println("Voting to the Candidate by providing voter Id and Candidate Id: ");
		System.out.println("Enter Voter Id : ");
		int voterId =sc.nextInt();
		
		System.out.println("Enter Candidate Id which you want to Vote: ");
		int candidateId =sc.nextInt();
		sc.close();
		VotingProcess voting = new VotingProcess(voterId, candidateId); 
		boolean result=VotingDAO.insert(voting);
		
		if(result)
		{
			System.out.println("Vote Cast SuccessFully...");
			System.out.println("......Thank For Voting.....");
		}
		else {
			System.out.println("Something went wrong!");
		}
		}
		catch (Exception e)
		{

			System.out.println("One Voter can Vote only One Candidate....");
		}
		
	}

}
