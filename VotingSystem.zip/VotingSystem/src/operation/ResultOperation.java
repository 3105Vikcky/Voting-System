package operation;

import java.util.Scanner;

import dao.ResultDAO;
import model.Result;

public class ResultOperation 
{
 public static void result(Scanner sc)
 {
	 System.out.println("Enter Election Title: ");
	 String ElectionTitle=sc.nextLine();
	 
	 sc.nextLine();
	 
	 System.out.println("Enter Result Date: ");
	 String resultDate=sc.nextLine();
	 
	 sc.nextLine();
	 
	 System.out.println("Enter Result Time: ");
	 String resultTime=sc.nextLine();
	 
	 Result obj2 = new Result(ElectionTitle, resultDate, resultTime); 
		boolean result=ResultDAO.insert(obj2);
		
		if(result)
		{
			System.out.println("....Result Date and Time Declared ...");
			System.out.println(".....................................");
		}
		else {
			System.out.println("Something went wrong!");
		}
 }
 
  public static void viewResultDateTime(Scanner sc)
  {
	  System.out.println("Enter Election Title: ");
	  String electionTitle=sc.nextLine();
	  sc.nextLine();
	  
	  Result rs =dao.ResultDAO.getResultDateTime(electionTitle);
	  if (rs!= null) 
		{
          System.out.println(rs);
      } else 
      {
          System.out.println(electionTitle + " result Date and Time not Declared Yet.");
      }
	  
  }
}
