package operation;

import java.util.Scanner;
import java.util.List;

import dao.CandidateDAO;
import model.Candidate;

public class CandidateOperation 
{
  public static void addCandidate(Scanner sc)
  {
	  System.out.println("Enter Candidate Id: ");
	  int candidate_id=sc.nextInt();
	  
	  sc.nextLine();
	  
	  System.out.println("Enter Candidate Name: ");
	  String candidate_name=sc.nextLine();
	  
	  System.out.println("Enter Candidate Age: ");
	  int candidate_age=sc.nextInt();
	  
	  sc.nextLine();
	  
	  System.out.println("Enter Candidate Citizenship: ");
	  String citizenship=sc.nextLine();
	  
	  System.out.println("Enter Candidate Political Party: ");
	  String political_party=sc.nextLine();
	  
	  System.out.println("Enter Candidate Address: ");
	  String candidate_address=sc.nextLine();
	  
	  //Creating object of Candidate Class
	  Candidate obj=new Candidate(candidate_id,candidate_name,candidate_age,citizenship,political_party,candidate_address);
	  
	  boolean result=CandidateDAO.insert(obj);
	  
	  if(result)
	  {
		  System.out.println("Candidate Added Succesfully.");
	  }
	  else{
		  System.out.println("Something went wrong!"); 
	  }
  }
  
  public static void updateCandidate(Scanner sc)
  {
	  System.out.println("Enter Candidate id which you want to update: ");
	  int candidate_id=sc.nextInt();
	  
	  sc.nextLine();
	  
	  System.out.println("Enter Candidate Name: ");
	  String candidate_name=sc.nextLine();
	  
	  System.out.println("Enter Candidate Age: ");
	  int candidate_age=sc.nextInt();
	  
	  sc.nextLine();
	  
	  System.out.println("Enter Candidate Citizenship: ");
	  String citizenship=sc.nextLine();
	  
	  System.out.println("Enter Candidate Political Party: ");
	  String political_party=sc.nextLine();
	  
	  System.out.println("Enter Candidate Address: ");
	  String candidate_address=sc.nextLine();
	  
	  Candidate obj=new Candidate(candidate_id,candidate_name,candidate_age,citizenship,political_party,candidate_address);
	  
	  boolean result=CandidateDAO.update(obj, candidate_id);
	  if(result)
	  {
		  System.out.println("Candidate  updated Successfully");
	  }
	  else {
		  System.out.println("Somethong went wrong!.");
	  }
	 }
  public static void deletebyID(Scanner sc)
  {
	  System.out.println("Enter Candidate id which you want to delete: ");
	  int candidate_id=sc.nextInt();
	  
	  boolean result=CandidateDAO.delete(candidate_id);
	  if(result)
	  {
		  System.out.println("Candidate with id "+candidate_id+" deleted Successfully.");
	  }
	  else {
		  System.out.println("Something went wrong!");
	  }
  }
  
 public static void showCandidateById(Scanner sc)
 {
	 System.out.println("Enter the Candidate ID which you want to show: ");
	 int candidate_id=sc.nextInt();
	 
	 Candidate candidate=CandidateDAO.getCandidateId(candidate_id);
	 if (candidate != null) 
		{
         System.out.println(candidate);
     } else 
     {
         System.out.println("Candidate with ID " + candidate_id + " not found.");
     }
 }
 
 public static void showAllCandidate()
 {
		List<Candidate> candidates = CandidateDAO.getAllCandidates();
		for(Candidate candidate:candidates)
		{
			System.out.println(candidate);
		}
 }
}
