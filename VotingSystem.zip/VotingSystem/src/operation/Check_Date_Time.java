package operation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import connection.VotingDBConnection;

public class Check_Date_Time {
    static PreparedStatement pstmt = null;
    static Connection conn = null;
    static ResultSet rs = null;

    public static void getDate(int electionId) {
        try {
            conn = VotingDBConnection.createC();
            String q = "SELECT electionDate FROM election WHERE electionId=?";
            pstmt = conn.prepareStatement(q);
            pstmt.setInt(1, electionId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String electionDateStr = rs.getString("electionDate");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); // Adjust the pattern to match your database date format
                LocalDate electionDate = LocalDate.parse(electionDateStr, formatter);

                LocalDate currentDate = LocalDate.now();

                if (electionDate.isBefore(currentDate)) {
                    System.out.println("The election was held by : "+ electionDate);
                    System.out.println("Check Upcoming Election");
                } else if (electionDate.isAfter(currentDate)) {
                    System.out.println("The election will held on:"+ electionDate);
                } else {
          
                     VotingOperation.castVote();
                     
                }
            } else {
                System.out.println("No election found with the given ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
    }

    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
