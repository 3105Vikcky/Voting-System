package operation;

import dao.ResultViewDAO;
import model.ResultView;

import java.util.List;

public class ResultViewOperation 
{
	public static void checkResult()
	{
		// Get all voting results
        List<ResultView> results = ResultViewDAO.getAllVotingResults();

        // Check if there are any results
        if (results.isEmpty()) {
            System.out.println("No votes found.");
            return;
        }

        // Display each candidate's results
        System.out.println("Voting Results:");
        for (ResultView result : results) {
            System.out.println("Candidate ID: " + result.getCandidateId() + " - Votes: " + result.getVoteCount());
        }

        // Determine the candidate with the highest votes
        ResultView topCandidate = results.get(0);
        System.out.println("\nCandidate with the highest votes:");
        System.out.println("Candidate ID: " + topCandidate.getCandidateId() + " - Votes: " + topCandidate.getVoteCount());
	}

}
