package operation;

import java.util.Scanner;


import model.Election;
import dao.ElectionDAO;
public class ElectionOperation 
{
	public static void addElection(Scanner sc)
	{
		System.out.println("Enter Election Title: ");
		String electionTitle = sc.nextLine();
		sc.nextLine();
		
		System.out.println("Enter Date of Election: ");
		String electionDate=sc.nextLine();
		
		System.out.println("Enter Election Start Time: ");
		String startTime=sc.nextLine();
		
		System.out.println("Enter Election End Time: ");
		String endTime=sc.nextLine();
		
		Election obj=new Election(electionTitle, electionDate, startTime,endTime );
        boolean result=ElectionDAO.insert(obj);
		
		if(result)
		{
			System.out.println("Election Declare Successfully ");
			System.out.println("To Continue Follow the steps.....");
		}
		else {
			System.out.println("Something went wrong!");
		}
	}
	
	public static void updateElection(Scanner sc)
	{
		System.out.println("Enter Election Title: ");
		String electionTitle = sc.nextLine();
		sc.nextLine();
		
		System.out.println("Enter Date of Election: ");
		String electionDate=sc.nextLine();
		sc.nextLine();
		
		System.out.println("Enter Election Start Time: ");
		String startTime=sc.nextLine();
		sc.nextLine();
		
		System.out.println("Enter Election End Time: ");
		String endTime=sc.nextLine();
		
		Election obj=new Election(electionTitle, electionDate, startTime,endTime );
        boolean result=ElectionDAO.update(obj,electionTitle);
		
		if(result)
		{
			System.out.println("Election Updated Successfully ");
			System.out.println("To Continue Follow the steps.....");
		}
		else {
			System.out.println("Something went wrong!");
		}
		
	}
	
	public static void removeElection(Scanner sc)
	{
		System.out.println("Enter Election Title for removing All details: ");
		String electionTitle = sc.nextLine();
		
		boolean result=ElectionDAO.delete(electionTitle);
		if(result)
		{
			System.out.println("Election deleted Successfully ");
		}
		else {
			System.out.println("Something went wrong!");
		}
	}
	public static void ShowElection(Scanner sc)
	{
		System.out.println("Enter election Title for details: ");
		String electionTitle = sc.nextLine();
		sc.nextLine();
		
		Election election=dao.ElectionDAO.getElectionDetailsByTitle(electionTitle);
		
		if (election!= null) 
		{
            System.out.println(election);
        } else 
        {
            System.out.println(electionTitle + " is not found");
        }
	}
}
