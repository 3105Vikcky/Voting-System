package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.VotingDBConnection;
import model.Voter;

public class VoterDAO 
{
	//for database related operation create variables
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    // Insert method handles auto-increment
    public static boolean insert(Voter obj) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //insert query for inserting value in Voter table
            String q = "INSERT INTO voter(VoterId, VoterName, Age, Citizenship, DOB, Address) VALUES (?, ?, ?, ?, ?,?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, obj.getVoterId());
            pstmt.setString(2, obj.getVoterName());
            pstmt.setInt(3, obj.getAge());
            pstmt.setString(4, obj.getCitizenship());
            pstmt.setString(5, obj.getDOB());
            pstmt.setString(6, obj.getAddress());

            pstmt.executeUpdate();

            f = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }

    // Update Voter
    public static boolean update(Voter obj, int VoterId) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //update query for updating value in voter table
            String q = "UPDATE voter SET VoterName = ?,  Age = ?, Citizenship=?, DOB=?, Address=? WHERE VoterId = ?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, obj.getVoterId());
            pstmt.setString(2, obj.getVoterName());
            pstmt.setInt(3, obj.getAge());
            pstmt.setString(4, obj.getCitizenship());
            pstmt.setString(5, obj.getDOB());
            pstmt.setString(6, obj.getAddress());

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Delete Method
    public static boolean delete(int VoterId) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();

          //delete query for delete value in voter table
            String qDelete = "DELETE FROM voter WHERE VoterId=?";
            pstmt = conn.prepareStatement(qDelete);
            pstmt.setInt(1, VoterId);

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Voter by VoterId
    public static Voter getVoterId(int VoterId) {
    	Voter vote = null;
        try {
            conn = VotingDBConnection.createC();

          //Select query for retriving the voter details by Id
            String q = "SELECT * FROM voter WHERE VoterId=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, VoterId);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                vote = new Voter();
                vote.setVoterId(rs.getInt("VoterId"));
                vote.setVoterName(rs.getString("VoterName"));
                vote.setAge(rs.getInt("Age"));
                vote.setCitizenship(rs.getString("Citizenship"));
                vote.setDOB(rs.getString("DOB"));
                vote.setAddress(rs.getString("Address"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return vote;
    }

    public static List<Voter> getAllVoters() {
        List<Voter> Voters = new ArrayList<>();
        try {
            conn = VotingDBConnection.createC();

            String q = "SELECT * FROM voter";
            stmt = conn.createStatement();

            rs = stmt.executeQuery(q);

            while (rs.next()) {
            	Voter voter = new Voter();
            	voter.setVoterId(rs.getInt("VoterId"));
                voter.setVoterName(rs.getString("VoterName"));
                voter.setAge(rs.getInt("Age"));
                voter.setCitizenship(rs.getString("Citizenship"));
                voter.setDOB(rs.getString("DOB"));
                voter.setAddress(rs.getString("Address"));
                Voters.add(voter);
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return Voters;
    }

    // Close resources method
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
