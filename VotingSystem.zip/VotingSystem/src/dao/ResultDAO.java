package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.Result;
import connection.VotingDBConnection;

public class ResultDAO 
{
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    
    public static boolean insert(Result result)
    {
  	  boolean f = false;
  	  try 
  	  {
  		  conn = VotingDBConnection.createC();
  		  
  		  String q = "INSERT INTO result(ElectionTitle, resultDate,resultTime) VALUES (?, ?,?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, result.getElectionTitle());
            pstmt.setString(2, result.getResultDate());
            pstmt.setString(3, result.getResltTime());

            pstmt.executeUpdate();

            f = true;

  		  
  	  }
  	  catch(SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }
    
    public static Result getResultDateTime(String electionTitle) {
    	Result result = null;
        try {
            conn = VotingDBConnection.createC();

            String q = "SELECT * FROM result WHERE ElectionTitle=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, electionTitle);

            rs = pstmt.executeQuery();

            if (rs.next()) {
            	result = new Result();
            	result.setElectionTitle(rs.getString("ElectionTitle"));
            	result.setResultDate(rs.getString("resultDate"));
            	result.setResltTime(rs.getString("resultTime"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return result;
    }
    
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
