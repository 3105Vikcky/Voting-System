package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.Result;
import connection.VotingDBConnection;

public class ResultDAO 
{
	//for database related operation create variables
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    
    public static boolean insert(Result result)
    {
  	  boolean f = false;
  	  try 
  	  {
  		  conn = VotingDBConnection.createC();
  		  
  		//insert query for inserting value in result table
  		  String q = "INSERT INTO result(electionId, resultDate,resultTime) VALUES (?, ?,?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, result.getElectionId());
            pstmt.setString(2, result.getResultDate());
            pstmt.setString(3, result.getResltTime());

            pstmt.executeUpdate();

            f = true;

  		  
  	  }
  	  catch(SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }
    
    public static Result getResultDateTime(int electionId) {
    	Result result = null;
        try {
            conn = VotingDBConnection.createC();
            
            // retrive election details by election id
            String q = "SELECT * FROM result WHERE electionId=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, electionId);

            rs = pstmt.executeQuery();

            if (rs.next()) {
            	result = new Result();
            	result.setElectionId(rs.getInt("electionId"));
            	result.setResultDate(rs.getString("resultDate"));
            	result.setResltTime(rs.getString("resultTime"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return result;
    }
    
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
