package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.VotingProcess;
import connection.VotingDBConnection;

public class VotingDAO 
{
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    
  public static boolean insert(VotingProcess vote)
  {
	  boolean f = false;
	  try 
	  {
		  conn = VotingDBConnection.createC();
		  
		  String q = "INSERT INTO voting(candidateId, voterId) VALUES (?, ?)";
          pstmt = conn.prepareStatement(q);

          pstmt.setInt(1, vote.getCandidateId());
          pstmt.setInt(2, vote.getVoterId());

          pstmt.executeUpdate();

          f = true;

		  
	  }
	  catch(SQLException e) {
          e.printStackTrace();
      } finally {
          // Close resources
          closeResources();
      }
      return f;
  }
  
  
  private static void closeResources() {
      try {
          if (pstmt != null)
              pstmt.close();
          if (rs != null)
              rs.close();
          if (conn != null)
              conn.close();
      } catch (SQLException e) {
          e.printStackTrace();
      }
  }
}
