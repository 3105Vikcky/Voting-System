package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import connection.VotingDBConnection;
import model.Election;
public class ElectionDAO 
{
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    public static boolean insert(Election obj) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();

            String q = "INSERT INTO election(electionTitle, electionDate, startTime,endTime) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, obj.getElectionTitle());
            pstmt.setString(2, obj.getElectionDate());
            pstmt.setString(3, obj.getStartTime());
            pstmt.setString(4, obj.getEndTime());

            pstmt.executeUpdate();

            f = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }

    // Update Election
    public static boolean update(Election obj, String electionTitle) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();

            String q = "UPDATE election SET electionDate = ?,  startTime = ?, endTime=? WHERE electionTitle = ?";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, obj.getElectionTitle());
            pstmt.setString(2, obj.getElectionDate());
            pstmt.setString(3, obj.getStartTime());
            pstmt.setString(4, obj.getEndTime());

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Delete Method
    public static boolean delete(String electionTitle) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();

            String qDelete = "DELETE FROM voter WHERE VoterId=?";
            pstmt = conn.prepareStatement(qDelete);
            pstmt.setString(1, electionTitle);

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }
    
    public static Election getElectionDetailsByTitle(String electionTitle)
    {
    	Election obj1 = null;
    	try {
            conn = VotingDBConnection.createC();

            String q = "SELECT * FROM election WHERE electionTitle=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setString(1, electionTitle);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                 obj1=new Election();
                obj1.setElectionTitle(rs.getString("electionTitle"));
                obj1.setElectionDate(rs.getString("electionDate"));
                obj1.setStartTime(rs.getString("startTime"));
                obj1.setEndTime(rs.getString("endTime"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return obj1;
    }
    
    
    
    
    
    
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
