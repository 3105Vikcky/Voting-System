package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import connection.VotingDBConnection;
import model.Election;
public class ElectionDAO 
{
	//for database related operation create variables
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    public static boolean insert(Election obj) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //insert query for inserting value in election table
            String q = "INSERT INTO election(electionId, electionDate, startTime,endTime) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, obj.getElectionId());
            pstmt.setString(2, obj.getElectionDate());
            pstmt.setString(3, obj.getStartTime());
            pstmt.setString(4, obj.getEndTime());

            pstmt.executeUpdate();

            f = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }

    // Update Election
    public static boolean update(Election obj, int electionId) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //update query for updating value in election table
            String q = "UPDATE election SET electionDate = ?,  startTime = ?, endTime=? WHERE electionId = ?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, obj.getElectionId());
            pstmt.setString(2, obj.getElectionDate());
            pstmt.setString(3, obj.getStartTime());
            pstmt.setString(4, obj.getEndTime());

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Delete Method
    public static boolean delete(int electionId) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //delete query for delete value in election table
            String qDelete = "DELETE FROM election WHERE electionId=?";
            pstmt = conn.prepareStatement(qDelete);
            pstmt.setInt(1, electionId);

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }
    
    public static Election getElectionDetailsById(int electionId)
    {
    	Election obj1 = null;
    	try {
            conn = VotingDBConnection.createC();
            
            
            // retrive election details with the election id
            String q = "SELECT * FROM election WHERE electionId=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, electionId);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                 obj1=new Election();
                obj1.setElectionId(rs.getInt("electionId"));
                obj1.setElectionDate(rs.getString("electionDate"));
                obj1.setStartTime(rs.getString("startTime"));
                obj1.setEndTime(rs.getString("endTime"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return obj1;
    }
    
    
    
    
    
    
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
