package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import connection.VotingDBConnection;
import model.ResultView;

public class ResultViewDAO {
    static PreparedStatement pstmt = null;
    static Connection conn = null;
    static ResultSet rs = null;

    public static List<ResultView> getAllVotingResults() {
        List<ResultView> results = new ArrayList<>();
        try {
            conn = VotingDBConnection.createC();

            String q = "SELECT candidateId, COUNT(vote) as voteCount FROM Voting GROUP BY candidateId ORDER BY voteCount DESC";
            pstmt = conn.prepareStatement(q);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                ResultView result = new ResultView();
                result.setCandidateId(rs.getInt("candidateId"));
                result.setVoteCount(rs.getInt("voteCount"));
                results.add(result);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return results;
    }

    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

