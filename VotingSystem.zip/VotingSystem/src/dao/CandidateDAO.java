package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.VotingDBConnection;
import model.Candidate;
public class CandidateDAO 
{
	//for database related operation create variables 
	static PreparedStatement pstmt = null;
    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;
    
 // Insert method handles auto-increment
    public static boolean insert(Candidate obj) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            //insert query for inserting value in candidate table 
            String q = "INSERT INTO candidate(CandidateId, CandidateName, CandidateAge, Citizenship, PoliticalParty, CandidateAddress) VALUES (?, ?, ?, ?, ?,?)";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, obj.getCandidateId());
            pstmt.setString(2, obj.getCandidateName());
            pstmt.setInt(3, obj.getCandidateAge());
            pstmt.setString(4, obj.getCitizenship());
            pstmt.setString(5, obj.getPoliticalParty());
            pstmt.setString(6, obj.getCandidateAddress());

            pstmt.executeUpdate();

            f = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources();
        }
        return f;
    }

    // Update Voter
    public static boolean update(Candidate obj, int CandidateId) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //updating query for updating value in candidate table
            String q = "UPDATE candidate SET CandidateName = ?,  CandidateAge = ?, Citizenship=?, PoliticalParty=?, CandidateAddress=? WHERE CandidateId = ?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, obj.getCandidateId());
            pstmt.setString(2, obj.getCandidateName());
            pstmt.setInt(3, obj.getCandidateAge());
            pstmt.setString(4, obj.getCitizenship());
            pstmt.setString(5, obj.getPoliticalParty());
            pstmt.setString(6, obj.getCandidateAddress());
            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Delete Method
    public static boolean delete(int CandidateId) {
        boolean f = false;
        try {
            conn = VotingDBConnection.createC();
            
          //delete query for delete value in candidate table
            String qDelete = "DELETE FROM candidate WHERE CandidateId=?";
            pstmt = conn.prepareStatement(qDelete);
            pstmt.setInt(1, CandidateId);

            pstmt.executeUpdate();
            f = true;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return f;
    }

    // Candidate by CandidateId
    public static Candidate getCandidateId(int CandidateId) {
    	Candidate candidate = null;
        try {
            conn = VotingDBConnection.createC();
            
            //Select query for retriving the candidate details by Id 
            String q = "SELECT * FROM candidate WHERE CandidateId=?";
            pstmt = conn.prepareStatement(q);

            pstmt.setInt(1, CandidateId);

            rs = pstmt.executeQuery();

            if (rs.next()) {
            	candidate = new Candidate();
                candidate.setCandidateId(rs.getInt("CandidateId"));
                candidate.setCandidateName(rs.getString("CandidateName"));
                candidate.setCandidateAge(rs.getInt("CandidateAge"));
                candidate.setCitizenship(rs.getString("Citizenship"));
                candidate.setPoliticalParty(rs.getString("PoliticalParty"));
                candidate.setCandidateAddress(rs.getString("CandidateAddress"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return candidate;
    }

    public static List<Candidate> getAllCandidates() {
        List<Candidate> Candidates = new ArrayList<>();
        try {
            conn = VotingDBConnection.createC();
            
            //retrive all candidate  
            String q = "SELECT * FROM Candidate";
            stmt = conn.createStatement();

            rs = stmt.executeQuery(q);

            while (rs.next()) {
            	Candidate candid = new Candidate();
            	candid.setCandidateId(rs.getInt("CandidateId"));
            	candid.setCandidateName(rs.getString("CandidateName"));
            	candid.setCandidateAge(rs.getInt("CandidateAge"));
            	candid.setCitizenship(rs.getString("Citizenship"));
            	candid.setPoliticalParty(rs.getString("PoliticalParty"));
            	candid.setCandidateAddress(rs.getString("CandidateAddress"));
            	Candidates.add(candid);
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources();
        }
        return Candidates;
    }

    // Close resources method
    private static void closeResources() {
        try {
            if (pstmt != null)
                pstmt.close();
            if (rs != null)
                rs.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
