package model;

public class Voter 
{
	//Voter related Attribute
	private  int VoterId;
	private String VoterName;
	private int Age;
	private String Citizenship;
	private String DOB;
	private String Address;
	
	//Constructor for initializing the voter variable
	public  Voter(int voterId, String voterName, int Age, String Citizenship, String DOB, String Address)
	{
		this.VoterId=voterId;
		this.VoterName=voterName;
		this.Age=Age;
		this.Citizenship=Citizenship;
		this.DOB=DOB;
		this.Address=Address;
	}
	public Voter()
	{
		// TODO Auto-generated constructor stub
	}
	
	//Getter and Setter method
	public int getVoterId() {
		return VoterId;
	}

	public void setVoterId(int voterId) {
		this.VoterId = voterId;
	}

	public String getVoterName() {
		return VoterName;
	}

	public void setVoterName(String voterName) {
		this.VoterName = voterName;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public String getCitizenship() {
		return Citizenship;
	}

	public void setCitizenship(String citizenship) {
		Citizenship = citizenship;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}
	@Override
	public String toString() {
		return "Voter [VoterId=" + VoterId + ", VoterName=" + VoterName + ", Age=" + Age + ", Citizenship="
				+ Citizenship + ", DOB=" + DOB + ", Address=" + Address + "]";
	}
	
	
	
}
