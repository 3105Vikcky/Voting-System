package model;

public class Result 
{
	
 //Result related attribute
 private int electionId;
 private String resultDate;
 private String resltTime;
 

// Getters and Setters method
public int getElectionId() {
	return electionId;
}


public void setElectionId(int electionId) {
	this.electionId = electionId;
}


public String getResultDate() {
	return resultDate;
}


public void setResultDate(String resultDate) {
	this.resultDate = resultDate;
}


public String getResltTime() {
	return resltTime;
}


public void setResltTime(String resltTime) {
	this.resltTime = resltTime;
}


@Override
public String toString() {
	return "Result [electionId=" + electionId + ", resultDate=" + resultDate + ", resltTime=" + resltTime + "]";
}


//Consyructor for initializing Result variables
public Result(int electionId, String resultDate, String resltTime) {
	this.electionId = electionId;
	this.resultDate = resultDate;
	this.resltTime = resltTime;
}
 

public Result()
{
	////To-do
}

 
}
