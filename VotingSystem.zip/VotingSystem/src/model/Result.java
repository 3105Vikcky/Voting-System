package model;

public class Result 
{
 private String electionTitle;
 @Override
public String toString() {
	return "Result [electionTitle=" + electionTitle + ", resultDate=" + resultDate + ", resltTime=" + resltTime + "]";
}


public Result(String electionTitle, String resultDate, String resltTime) {
	super();
	this.electionTitle = electionTitle;
	this.resultDate = resultDate;
	this.resltTime = resltTime;
}


public String getElectionTitle() {
	return electionTitle;
}


public void setElectionTitle(String electionTitle) {
	this.electionTitle = electionTitle;
}


public String getResultDate() {
	return resultDate;
}


public void setResultDate(String resultDate) {
	this.resultDate = resultDate;
}


public String getResltTime() {
	return resltTime;
}


public void setResltTime(String resltTime) {
	this.resltTime = resltTime;
}


private String resultDate;
 private String resltTime;
 

public Result()
{
	////To-do
}

 
}
