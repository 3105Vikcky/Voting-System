package model;

public class Election 
{
	private String electionTitle;
	private String  electionDate;
	private String startTime;
	private String endTime;
	
	
	public Election(String electionTitle, String electionDate, String startTime, String endTime) {
		this.electionTitle = electionTitle;
		this.electionDate = electionDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public Election()
	{
	//// TODO Auto-generated constructor stub
	}
	public String getElectionTitle() {
		return electionTitle;
	}
	public void setElectionTitle(String electionTitle) {
		this.electionTitle = electionTitle;
	}
	public String getElectionDate() {
		return electionDate;
	}
	public void setElectionDate(String electionDate) {
		this.electionDate = electionDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "Election [electionTitle=" + electionTitle + ", electionDate=" + electionDate + ", startTime="
				+ startTime + ", endTime=" + endTime + "]";
	}
	
	

}
