package model;

public class Election 
{
	// Election related attribute
	private int electionId;
	private String  electionDate;
	private String startTime;
	private String endTime;
	
	// Constructor to initialize the variable
	public Election(int electionId, String electionDate, String startTime, String endTime) {
		this.electionId = electionId;
		this.electionDate = electionDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public Election()
	{
	//// TODO Auto-generated constructor stub
	}
	
	//Getters and Setters method
	public int getElectionId() {
		return electionId;
	}
	public void setElectionId(int electionId) {
		this.electionId = electionId;
	}
	public String getElectionDate() {
		return electionDate;
	}
	public void setElectionDate(String electionDate) {
		this.electionDate = electionDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "Election [electionId=" + electionId + ", electionDate=" + electionDate + ", startTime="
				+ startTime + ", endTime=" + endTime + "]";
	}
	
	

}
