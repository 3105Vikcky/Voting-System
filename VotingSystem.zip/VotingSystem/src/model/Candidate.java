package model;
public class Candidate 
{
	private int CandidateId;
	private String CandidateName;
	private int CandidateAge;
	private String Citizenship;
	private String PoliticalParty;
	private String CandidateAddress;
	
	

	public Candidate(int candidateId, String candidateName,int candidateAge, String citizenship, String politicalParty,
			String candidateAddress) 
	{
		this.CandidateId = candidateId;
		this.CandidateName = candidateName;
		this.CandidateAge = candidateAge;
		this.Citizenship = citizenship;
		this.PoliticalParty= politicalParty;
		this.CandidateAddress = candidateAddress;
	}
	public Candidate()
	{
		//// TODO Auto-generated constructor stub
	}
	
	public String getCandidateName() 
	{
		return CandidateName;
	}
	public void setCandidateName(String candidateName) 
	{
		CandidateName = candidateName;
	}
	public int getCandidateId() 
	{
		return CandidateId;
	}
	public void setCandidateId(int candidateId) 
	{
		CandidateId = candidateId;
	}
	public String getCitizenship() 
	{
		return Citizenship;
	}
	public void setCitizenship(String citizenship) 
	{
		Citizenship = citizenship;
	}
	public int getCandidateAge() 
	{
		return CandidateAge;
	}
	public void setCandidateAge(int candidateAge) 
	{
		CandidateAge = candidateAge;
	}
	public String getCandidateAddress() 
	{
		return CandidateAddress;
	}
	public void setCandidateAddress(String candidateAddress) 
	{
		CandidateAddress = candidateAddress;
	}
	public String getPoliticalParty() 
	{
		return PoliticalParty;
	}
	public void setPoliticalParty(String politicalParty) 
	{
		PoliticalParty = politicalParty;
	}
	@Override
	public String toString() {
		return "Candidate [CandidateId=" + CandidateId + ", CandidateName=" + CandidateName + ", CandidateAge="
				+ CandidateAge + ", Citizenship=" + Citizenship + ", PoliticalParty=" + PoliticalParty
				+ ", CandidateAddress=" + CandidateAddress + "]";
	}
	
	
	
}
