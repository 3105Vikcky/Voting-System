package model;

public class VotingProcess 
{
	//Voting Process related attribute
	private int voterId;
	private  int candidateId;
	
	public VotingProcess()
	{
	//// TODO Auto-generated constructor stub
	}

	//getter And Setter Attribute
	public int getVoterId() {
		return voterId;
	}

	public void setVoterId(int voterId) {
		this.voterId = voterId;
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	@Override
	public String toString() {
		return "VotingProcess [voterId=" + voterId + ", candidateId=" + candidateId + "]";
	}

	
	// Constructor for initializing the voting process variable
	public VotingProcess(int voterId, int candidateId) {
		super();
		this.voterId = voterId;
		this.candidateId = candidateId;
	}
	
	
	
	

}
