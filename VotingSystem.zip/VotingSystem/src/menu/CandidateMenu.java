package menu;

import java.util.Scanner;

import main.MainMenu;
import operation.CandidateOperation;
import operation.ElectionOperation;
import operation.ResultOperation;
public class CandidateMenu 
{
	public static void candidatemenu(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\nWelcome to Candidate Page\n");
	           System.out.println("Press 1 for View your Profile by ID: ");
	           System.out.println("Press 2 for View Election Details: ");
	           System.out.println("Press 3 for View Result Date And Time: ");
	           System.out.println("Press 0 to Logout from Candidate menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           sc.nextLine();
	           switch (choice) {
	               case 1:
	                   CandidateOperation.showCandidateById(sc);
	                   break;
	               case 2:
	            	   ElectionOperation.ShowElection(sc);
	            	   break;
	               case 3:
	            	   ResultOperation.viewResultDateTime(sc);
	            	   break;
	               case 0:
	                   System.out.println("Logged out successfully from candidate page.");
	                   System.out.println();
	                   System.out.println();
	                   MainMenu ob1=new MainMenu();
	                   ob1.login();
	                   ob1.mainMenu();
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }
}
