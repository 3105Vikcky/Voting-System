package menu;

import main.VotingSystemMain;

import java.util.Scanner;

import operation.CandidateOperation;
import operation.VoterOperation;
import operation.ElectionOperation;
import operation.ResultOperation;
import operation.ResultViewOperation;

public class AdminMenu {

	// Admin menu
	   public static void adminMenu(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\n!!!!                   Welcome to Admin Page           !!!!\n");
	           System.out.println("Press 1 for Election  operations");
	           System.out.println("Press 2 for Voter operations");
	           System.out.println("Press 3 for Candidate Oparations");
	           System.out.println("Press 4 for Result Opearation");
	           System.out.println("Press 0 to Logout from Admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	                   manageElection(sc);
	                   break;
	               case 2:
	                   manageVoter(sc);
	                   break;
	                   
	               case 3:
	            	   manageCandidate(sc);
	            	   break;
	               case 4:
	            	   manageResult(sc);
	               case 0:
	                   System.out.println("Logged out successfully from Admin page.");
	                   System.out.println();
	                   System.out.println();
	                   String [] args=null;
	                   VotingSystemMain.main(args);
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }
	   
	   public static void manageElection(Scanner sc)
	   {
		   int choice;
	       do {
	           System.out.println("\n               Welcome to Election operation               \n");
	           System.out.println("Press 1 to Add Election Details ");
	           System.out.println("Press 2 to View Election Details");
	           System.out.println("Press 3 to Update Election Details ");
	           System.out.println("Press 4 to Remove Election");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           
	           sc.nextLine();
	           
	           switch (choice) {
	               case 1:
	                   ElectionOperation.addElection(sc);
	                   break;
	               case 2:
	            	   ElectionOperation.ShowElection(sc);
	                   break;
	               case 3:
	            	   ElectionOperation.updateElection(sc);
	                   break;
	               case 4:
	            	   ElectionOperation.removeElection(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   adminMenu(sc);
	                   break;
	                   
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0); 
	   }

	   public static void manageCandidate(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\n               Welcome to Candidate operation                \n");
	           System.out.println("Press 1 to Nominate  Candidate ");
	           System.out.println("Press 2 to Update Candidate");
	           System.out.println("Press 3 to View all Candidate");
	           System.out.println("Press 4 to View Candidate by Id");
	           System.out.println("Press 5 to Delete Candidate by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	                   CandidateOperation.addCandidate(sc);
	                   break;
	               case 2:
	            	   CandidateOperation.updateCandidate(sc);
	                   break;
	               case 3:
	            	   CandidateOperation.showAllCandidate();
	                   break;
	               case 4:
	            	   CandidateOperation.showCandidateById(sc);
	                   break;
	               case 5:
	            	   CandidateOperation.deletebyID(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   adminMenu(sc);
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }

	   public static void manageVoter(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\n                  Welcome to Voter operation                 \n");
	           System.out.println("Press 1 to Add a Voter");
	           System.out.println("Press 2 to Update a Voter");
	           System.out.println("Press 3 to View all Voter");
	           System.out.println("Press 4 to View Voter by Id");
	           System.out.println("Press 5 to Delete Voter by Id");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           switch (choice) {
	               case 1:
	                   VoterOperation.addVoters(sc);
	                   break;
	               case 2:
	            	   VoterOperation.updateVoter(sc);
	                   break;
	               case 3:
	            	   VoterOperation.ShowAllVoters();
	                   break;
	               case 4:
	            	   VoterOperation.showVoterByID(sc);
	                   break;
	               case 5:
	            	   VoterOperation.deleteVoterByID(sc);
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   adminMenu(sc);
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }
	   
	   
	   public static void manageResult(Scanner sc) {
	       int choice;
	       do {
	           System.out.println("\n                Welcome to Result operation               \n");
	           System.out.println("Press 1 to Add Result Date and Time: ");
	           System.out.println("Press 2 to for View Result Date and Time:");
	           System.out.println("Press 3 to for View Result:");
	           System.out.println("Press 0 for returning to admin menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           sc.nextLine();
	           switch (choice) {
	               case 1:
	                   ResultOperation.result(sc);
	                   break;
	               case 2:
	            	   ResultOperation.viewResultDateTime(sc);
	                   break;
	               case 3:
	            	   ResultViewOperation.checkResult();
	                   break;
	               case 0:
	                   System.out.println("Returning back to admin menu.");
	                   adminMenu(sc);
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
	   }
	   

	   
	   
}
