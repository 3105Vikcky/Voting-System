package menu;
import java.util.Scanner;

import main.VotingSystemMain;
import operation.VoterOperation;
import operation.ElectionOperation;
import operation.ResultOperation;
import operation.CandidateOperation;
import operation.Check_Date_Time;

public class VoterMenu 
{
	public static void votermenu(Scanner sc)
	{
	       int choice;
	       do {
	           System.out.println("\n                    Welcome to Voter Page\n");
	           System.out.println("Press 1 for View your Profile by ID: ");
	           System.out.println("Press 2 for checking Eligibility by Age: ");
	           System.out.println("Press 3 for View Election Details: ");
	           System.out.println("Press 4 for View Candidate List: ");
	           System.out.println("Press 5 for Vote to the Candidate : ");
	           System.out.println("Press 6 for View Result Date And Time: ");
	           System.out.println("Press 0 to Logout from Voter menu");

	           System.out.print("\nEnter your choice: ");
	           choice = sc.nextInt();
	           sc.nextLine();
	           switch (choice) {
	               case 1:
	                   VoterOperation.showVoterByID(sc);
	                   break;
	               case 2:
	            	   System.out.println("Enter Your Age:");
	            	   int age = sc.nextInt();
	            	   if(age>=18)
	            	   {
	            		   System.out.println("You are eligible for Voting.");
	    
	            	   }
	            	   else {
	            		   System.out.println("You are not eligible.");
	            	   }
	            	   break;
	               case 3:
	            	   ElectionOperation.ShowElection(sc);
	            	   break;
	            	   
	               case 4:
	            	   CandidateOperation.showAllCandidate();
	            	   break;
	               case 5:
	            	   System.out.println("Enter Election Id: ");
	            	   int ElectionId=sc.nextInt();
	            	   sc.nextLine();
	            	   Check_Date_Time.getDate(ElectionId);
	            	   break;
	               case 6:
	            	   ResultOperation.viewResultDateTime(sc);
	            	   break;
	               case 0:
	                   System.out.println("Logged out successfully from Voter page.");
	                   System.out.println();
	                   System.out.println("\n\n");
	                   String [] args=null;
	                   VotingSystemMain.main(args);
	                   break;
	               default:
	                   System.out.println("Invalid choice. Please try again.");
	           }
	       } while (choice != 0);
 }
}
