package main;

import java.util.InputMismatchException;
import java.util.Scanner;
public class VotingSystemMain 
{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		MainMenu menu1 = new MainMenu();
		try {
        int choice;
        do {
        	
        	System.out.println("!!!       **********Welcome to Voting Management System***********         !!!");
 	           System.out.println("\n\nPress 1 for Login");
 	           System.out.println("Press 2 For Registration");
 	           System.out.println("Press 0 to Exit from Voting System");

 	           System.out.print("\nEnter your choice: ");
 	          choice = sc.nextInt();
 	           switch (choice) {
 	               case 1:
 	            	   menu1.login();
 	            	   menu1.mainMenu();
 	                   break;
 	               case 2:
 	            	   menu1.registration();
 	            	   System.out.println();
 	            	   System.out.println();
 	            	   menu1.login();
 	            	  menu1.mainMenu();
 	                   break;
 	               case 0:
 	            	   System.out.println("-----------------Thank You-----------------");
 	              default:
	                   System.out.println("Invalid choice. Please try again.");
	                   break;
 	         }
        }while (choice != 0);
        sc.close();
		}
		catch(InputMismatchException ie)
		{
			System.out.println("Please Enter only Number:");
			System.out.println();
			System.out.println();
			main(args);
		}
   }
	
}
