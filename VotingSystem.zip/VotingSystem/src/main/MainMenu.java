package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import connection.VotingDBConnection;
import menu.AdminMenu;
import menu.CandidateMenu;
import menu.VoterMenu;

public class MainMenu {
	private  String roleName;
	private Scanner sc = new Scanner(System.in);

	public void login() {
		
		

			System.out.println("*******Login to Voting  System by providing your credentials: *******");

			System.out.println("Enter username: ");
			String username = sc.nextLine();

			System.out.println("Enter password: ");
			String password = sc.nextLine();

			try (Connection con = VotingDBConnection.createC()) {
				Statement st = con.createStatement();
			String fetchQuery = "SELECT userType FROM Login WHERE username = '" + username + "' AND password = '"
					+ password + "'";

			ResultSet rs = st.executeQuery(fetchQuery);

			if (rs.next()) {
				roleName = rs.getString("userType");
				System.out.println("Login successful as " + roleName);
				System.out.println("Thankyou for Login.");
			} else {
				System.out.println("Wrong credentials. Please check the username and password.");
				login();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
	// Main menu
	public void mainMenu() {
        try {
            if (roleName.equals("admin")) 
            {
                AdminMenu.adminMenu(sc);
            }
            
        else if (roleName.equals("candidate")) {
               CandidateMenu.candidatemenu(sc);
           } 
           else if (roleName.equals("voter")) {
           	VoterMenu.votermenu(sc);
           }
        } catch (NullPointerException e) {
            System.out.println("Not Found!!");
        }
        sc.next();
    }
	
	//registration Process
	public void registration()
	{
		System.out.println("Register to Voting System by providing your details:");

        System.out.println("Enter username: ");
        String username = sc.nextLine();

        System.out.println("Enter password: ");
        String password = sc.nextLine();

        System.out.println("Enter user type (admin/candidate/voter): ");
        String userType = sc.nextLine();

        try (Connection con = VotingDBConnection.createC()) {
            String insertQuery = "INSERT INTO Login (username, password, userType) VALUES (?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(insertQuery);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, userType);

            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("Registration successful!");
            } else {
                System.out.println("Registration failed. Please try again.");
                System.out.println();
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    
	}

}

